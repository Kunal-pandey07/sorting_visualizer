# Sorting-Visualizer
Immerse yourself in the world of sorting algorithms with our Sorting Visualizer project. Witness the magic of six powerful sorting methods through captivating animations. Tailor your data, control animation speed, and deepen your understanding of these algorithms. Experience the art of sorting, made simple and engaging. 📊📈
